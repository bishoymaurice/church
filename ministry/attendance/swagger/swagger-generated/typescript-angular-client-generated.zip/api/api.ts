export * from './minister.service';
import { MinisterService } from './minister.service';
export const APIS = [MinisterService];
